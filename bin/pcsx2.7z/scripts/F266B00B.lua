-- This scripting works similar to pnach files. There are the two mandatory functions: ExecuteOnceOnLoad and ExecuteContinuously.
-- As the names suggest, the first function is only executed once, when the game boots. The second function is executed on every frame refresh.
-- Without these two functions, the script will not be executed as they are the starting points.

-- At the moment of writing this file, there are six functions available. These are:
-- ReadByte(address), Read2Byte(address), Read4Byte(address)
-- WriteByte(address, value), Write2Byte(address, value), Write4Byte(address, value)
-- The memory functions will always default to the EE processor.

-- The default print() function is also available. The output will be displayed in the PCSX2 Console Log.

function ExecuteOnceOnLoad()
    print("Hello from Lua!")
end

function ExecuteContinuously()
    KillDoland()
end

function KillDoland()
    Write2Byte(0x21CE0B6A, 0)
end